# Greenman HedgeWitchery Android wrapper

This project packages the exact supplied `GREENMAN_HEDGEWITCHERY.html` inside a thin native Android WebView shell.

## Protected baseline

- Source file: `GREENMAN_HEDGEWITCHERY_GATHER_FAST_FIXED(1).html`
- HTML SHA-256: `90dd2304a3292124893ab2dba441762d1eb84b08173cf5e329bf0e04998618ef`
- No HTML, CSS, JavaScript, page styling, button styling, embedded page content, or app data was rewritten.
- The Android layer supplies only the launcher icon, fullscreen window, persistent WebView storage, local secure-origin asset loading, Android file picking, offline export saving, native print handoff, and basic physical Back handling.
- External navigation is blocked. The APK does not request Internet permission.

## Build

Requires Java 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.

```bash
gradle :app:assembleDebug
```

The installable test APK is created at:

`app/build/outputs/apk/debug/app-debug.apk`
